# WOW Gaming Launcher

Portrait Android home launcher prototype for the Samsung Galaxy S24-sized screen.

## Interaction

- One fixed desktop; only the central card deck moves.
- One large game-entry card is shown at a time, with a visible stack behind it.
- Swipe the card left/right to advance one card with snap animation.
- Tap an app icon inside the active card to launch it.
- Long-press the active card to choose up to four apps for that card.
- Long-press the empty top area to open the sizing/settings screen.
- Bottom five-app dock remains fixed.

## Build

Open the folder in Android Studio (JDK 17), allow Gradle sync, then build the `app` release or debug APK. The project intentionally uses only Android framework APIs and has no third-party runtime dependencies.

The card art master files are packaged in `app/src/main/res/drawable-nodpi/`.
