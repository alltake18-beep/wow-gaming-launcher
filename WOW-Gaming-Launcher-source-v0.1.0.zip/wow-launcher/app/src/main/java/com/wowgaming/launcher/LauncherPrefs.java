package com.wowgaming.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class LauncherPrefs {
    public static final String[] CARD_IDS = {"google", "system", "jackpot", "feature", "spin"};
    public static final String[] CARD_TITLES = {"GOOGLE", "SYSTEM", "JACKPOT", "FEATURE", "SPIN"};
    private final SharedPreferences p;
    public LauncherPrefs(Context c) { p = c.getSharedPreferences("launcher", Context.MODE_PRIVATE); }
    public float f(String key, float def) { return p.getFloat(key, def); }
    public int i(String key, int def) { return p.getInt(key, def); }
    public void put(String key, float value) { p.edit().putFloat(key, value).apply(); }
    public void put(String key, int value) { p.edit().putInt(key, value).apply(); }
    public List<String> apps(String card) {
        String raw = p.getString("apps_" + card, "");
        if (raw == null || raw.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(raw.split("\\|", -1)));
    }
    public void apps(String card, List<String> values) {
        p.edit().putString("apps_" + card, String.join("|", values)).apply();
    }
}
