package com.wowgaming.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    private LauncherPrefs prefs;
    private LinearLayout root;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=new LauncherPrefs(this); build();}
    private void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(36,48,36,72); root.setBackgroundColor(0xff0d0908); scroll.addView(root);
        title("WOW LAUNCHER 尺寸設定");
        slider("上方預留高度", "top_ratio", 20,50,32,100f);
        slider("主卡寬度", "card_width", 48,88,72,100f);
        slider("卡片高寬比", "card_ratio", 125,180,150,100f);
        slider("卡片垂直位置", "card_center_y", 42,72,58,100f);
        slider("後卡水平露出", "stack_x", 1,12,4,100f);
        slider("後卡垂直錯位", "stack_y", 0,5,1,100f);
        slider("後卡縮放差", "stack_scale", 1,8,3,100f);
        slider("後卡旋轉角度", "stack_rotation", 0,60,13,10f);
        intSlider("後方顯示張數", "stack_count", 1,6,4);
        slider("卡內 App 圖示", "card_icon_size", 8,20,12,100f);
        slider("Dock 圖示", "dock_icon_size", 8,20,12,100f);
        slider("Dock 底部距離", "dock_bottom", 2,14,6,100f);
        slider("滑動觸發距離", "swipe_threshold", 8,30,16,100f);
        intSlider("滑動動畫毫秒", "anim_ms", 160,520,260);
        TextView hint=new TextView(this); hint.setText("主畫面：左右滑動卡片；長按主卡可設定卡內 App；長按上方空白處回到本頁。"); hint.setTextColor(0xffd7c8b4); hint.setTextSize(15); hint.setPadding(0,36,0,24); root.addView(hint);
        Button done=new Button(this); done.setText("完成"); done.setOnClickListener(v->finish()); root.addView(done,new LinearLayout.LayoutParams(-1,-2)); setContentView(scroll);
    }
    private void title(String s){TextView v=new TextView(this);v.setText(s);v.setTextColor(0xffffd47a);v.setTextSize(23);v.setPadding(0,0,0,28);root.addView(v);}
    private void slider(String name,String key,int min,int max,int def,float div){
        TextView label=new TextView(this);label.setTextColor(Color.WHITE);label.setTextSize(16);root.addView(label);
        SeekBar bar=new SeekBar(this);bar.setMax(max-min);int now=Math.round(prefs.f(key,def/div)*div);bar.setProgress(now-min);label.setText(name+"："+format(now,div));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){int val=min+p;label.setText(name+"："+format(val,div));prefs.put(key,val/div);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});root.addView(bar,new LinearLayout.LayoutParams(-1,-2));
    }
    private void intSlider(String name,String key,int min,int max,int def){
        TextView label=new TextView(this);label.setTextColor(Color.WHITE);label.setTextSize(16);root.addView(label);SeekBar bar=new SeekBar(this);bar.setMax(max-min);int now=prefs.i(key,def);bar.setProgress(now-min);label.setText(name+"："+now);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){int val=min+p;label.setText(name+"："+val);prefs.put(key,val);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});root.addView(bar,new LinearLayout.LayoutParams(-1,-2));
    }
    private String format(int v,float d){return d==1?String.valueOf(v):String.format(java.util.Locale.US,"%.2f",v/d);}
}
