package com.wowgaming.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppPickerActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);String card=getIntent().getStringExtra("card");if(card==null)card="google";LauncherPrefs prefs=new LauncherPrefs(this);Set<String> selected=new HashSet<>(prefs.apps(card));List<AppEntry> apps=AppRepository.launchable(this);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(28,42,28,64);list.setBackgroundColor(0xff0d0908);TextView title=new TextView(this);title.setText(card.toUpperCase()+" 卡片內 App（最多 4 個）");title.setTextColor(0xffffd47a);title.setTextSize(22);title.setPadding(0,0,0,22);list.addView(title);ArrayList<CheckBox> checks=new ArrayList<>();
        for(AppEntry app:apps){CheckBox cb=new CheckBox(this);cb.setText(app.label);cb.setTextColor(Color.WHITE);cb.setTextSize(16);cb.setCompoundDrawablesWithIntrinsicBounds(app.icon,null,null,null);cb.setCompoundDrawablePadding(18);cb.setPadding(0,8,0,8);cb.setChecked(selected.contains(app.key()));checks.add(cb);list.addView(cb);}
        Button save=new Button(this);save.setText("儲存");String finalCard=card;save.setOnClickListener(v->{ArrayList<String> out=new ArrayList<>();for(int i=0;i<checks.size()&&out.size()<4;i++)if(checks.get(i).isChecked())out.add(apps.get(i).key());prefs.apps(finalCard,out);finish();});list.addView(save);
        ScrollView scroll=new ScrollView(this);scroll.addView(list);setContentView(scroll);
    }
}
