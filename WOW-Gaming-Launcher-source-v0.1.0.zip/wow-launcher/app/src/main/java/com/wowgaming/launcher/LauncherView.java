package com.wowgaming.launcher;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class LauncherView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final LauncherPrefs prefs;
    private final GestureDetector gestures;
    private final Bitmap[] cardArt;
    private final Map<String, RectF> hit = new HashMap<>();
    private List<AppEntry> allApps = new ArrayList<>();
    private List<AppEntry>[] cardApps;
    private List<AppEntry> dockApps = new ArrayList<>();
    private int front = 0;
    private float dragX = 0f;
    private boolean dragging;

    @SuppressWarnings("unchecked")
    public LauncherView(Context c) {
        super(c);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        prefs = new LauncherPrefs(c);
        cardArt = new Bitmap[]{
                BitmapFactory.decodeResource(getResources(), R.drawable.card_google),
                BitmapFactory.decodeResource(getResources(), R.drawable.card_system),
                BitmapFactory.decodeResource(getResources(), R.drawable.card_jackpot),
                BitmapFactory.decodeResource(getResources(), R.drawable.card_feature),
                BitmapFactory.decodeResource(getResources(), R.drawable.card_spin)};
        cardApps = new List[cardArt.length];
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public void onLongPress(MotionEvent e) {
                if (isInFrontCard(e.getX(), e.getY())) {
                    Intent i = new Intent(getContext(), AppPickerActivity.class);
                    i.putExtra("card", LauncherPrefs.CARD_IDS[front]);
                    getContext().startActivity(i);
                } else if (e.getY() < getHeight() * .36f) {
                    getContext().startActivity(new Intent(getContext(), SettingsActivity.class));
                }
            }
            @Override public boolean onSingleTapUp(MotionEvent e) {
                for (Map.Entry<String, RectF> h : hit.entrySet()) {
                    if (h.getValue().contains(e.getX(), e.getY())) { launch(h.getKey()); return true; }
                }
                return true;
            }
        });
        reload();
    }

    public void reload() {
        allApps = AppRepository.launchable(getContext());
        for (int x = 0; x < cardApps.length; x++) cardApps[x] = resolveCardApps(x);
        dockApps = resolveDock();
        invalidate();
    }

    private List<AppEntry> resolveCardApps(int index) {
        List<String> saved = prefs.apps(LauncherPrefs.CARD_IDS[index]);
        ArrayList<AppEntry> result = new ArrayList<>();
        for (String key : saved) { AppEntry a = AppRepository.findByKey(allApps, key); if (a != null) result.add(a); }
        if (!result.isEmpty()) return result;
        String[][] defaults = {
                {"google", "gmail", "maps", "photos"}, {"settings", "gallery", "message", "clock"},
                {"jackpot", "fun", "shopee", "uber"}, {"netflix", "team", "trello", "windy"},
                {"game", "play", "spin", "slot"}};
        for (String token : defaults[index]) {
            for (AppEntry a : allApps) if (!result.contains(a) && a.label.toLowerCase().contains(token)) { result.add(a); break; }
        }
        for (AppEntry a : allApps) { if (result.size() >= 4) break; if (!result.contains(a)) result.add(a); }
        return result;
    }

    private List<AppEntry> resolveDock() {
        String[] names = {"bubble", "jackpot", "surfshark", "chatgpt", "telegram"};
        ArrayList<AppEntry> result = new ArrayList<>();
        for (String n : names) {
            AppEntry chosen = null;
            for (AppEntry a : allApps) if (a.label.toLowerCase().contains(n)) { chosen = a; break; }
            if (chosen != null && !result.contains(chosen)) result.add(chosen);
        }
        return result;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        hit.clear();
        float w = getWidth(), h = getHeight();
        paint.setShader(new LinearGradient(0, 0, 0, h, new int[]{0xff070505, 0xff170806, 0xff07140f}, null, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint); paint.setShader(null);
        drawCasinoBackdrop(canvas, w, h);

        float topRatio = prefs.f("top_ratio", .32f);
        float cardWidth = w * prefs.f("card_width", .72f);
        float cardRatio = prefs.f("card_ratio", 1.5f);
        float cardHeight = Math.min(cardWidth * cardRatio, h * .55f);
        float cy = h * prefs.f("card_center_y", .58f);
        float cx = w * .5f + dragX;
        float stackX = w * prefs.f("stack_x", .04f);
        float stackY = h * prefs.f("stack_y", .01f);
        float scaleStep = prefs.f("stack_scale", .03f);
        float rotStep = prefs.f("stack_rotation", 1.3f);
        int visibleBack = prefs.i("stack_count", 4);

        for (int depth = visibleBack; depth >= 1; depth--) {
            int index = (front + depth) % cardArt.length;
            float scale = Math.max(.72f, 1f - depth * scaleStep);
            drawCard(canvas, index, cx + depth * stackX, cy - depth * stackY,
                    cardWidth * scale, cardHeight * scale, depth * rotStep, false);
        }
        drawCard(canvas, front, cx, cy, cardWidth, cardHeight, dragX / w * 9f, true);
        drawDots(canvas, w, cy + cardHeight * .55f);
        drawDock(canvas, w, h);
    }

    private void drawCasinoBackdrop(Canvas c, float w, float h) {
        paint.setColor(0x334f240d); c.drawCircle(w*.5f, h*.28f, w*.48f, paint);
        paint.setColor(0x55220b08); c.drawRect(0, h*.82f, w, h, paint);
        paint.setColor(0x44d9a441); c.drawRect(w*.05f, h*.815f, w*.95f, h*.817f, paint);
    }

    private void drawCard(Canvas c, int index, float cx, float cy, float width, float height, float rotation, boolean active) {
        c.save(); c.rotate(rotation, cx, cy);
        RectF dst = new RectF(cx-width/2, cy-height/2, cx+width/2, cy+height/2);
        paint.setShadowLayer(active ? 28f : 12f, 0, 10, 0xaa000000);
        c.drawBitmap(cardArt[index], null, dst, paint); paint.clearShadowLayer();
        if (active) drawCardApps(c, cardApps[index], dst);
        c.restore();
    }

    private void drawCardApps(Canvas c, List<AppEntry> apps, RectF card) {
        int count = Math.min(4, apps.size());
        if (count == 0) return;
        float icon = card.width() * prefs.f("card_icon_size", .12f);
        float y = card.bottom - card.height() * .16f;
        float total = count * icon + (count-1) * icon*.38f;
        float x = card.centerX() - total/2;
        for (int i=0; i<count; i++) {
            RectF r = new RectF(x, y-icon/2, x+icon, y+icon/2);
            drawDrawable(c, apps.get(i).icon, r);
            hit.put(apps.get(i).key(), new RectF(r.left-icon*.18f, r.top-icon*.18f, r.right+icon*.18f, r.bottom+icon*.18f));
            x += icon*1.38f;
        }
    }

    private void drawDots(Canvas c, float w, float y) {
        float gap = 22f * getResources().getDisplayMetrics().density;
        float start = w/2 - (cardArt.length-1)*gap/2;
        for (int i=0;i<cardArt.length;i++) { paint.setColor(i==front ? 0xffe6b84e : 0x66777777); c.drawCircle(start+i*gap,y, i==front?7:5,paint); }
    }

    private void drawDock(Canvas c, float w, float h) {
        float size = w * prefs.f("dock_icon_size", .12f);
        float bottom = h - h * prefs.f("dock_bottom", .055f);
        float left = w*.08f, available = w*.84f;
        int slots = 5;
        for (int i=0;i<slots;i++) {
            float cx = left + available*(i+.5f)/slots;
            RectF r = new RectF(cx-size/2,bottom-size,cx+size/2,bottom);
            if (i < dockApps.size()) { drawDrawable(c,dockApps.get(i).icon,r); hit.put(dockApps.get(i).key(),new RectF(r.left-12,r.top-12,r.right+12,r.bottom+12)); }
            else { paint.setColor(0x44333333); c.drawRoundRect(r,16,16,paint); }
        }
    }

    private void drawDrawable(Canvas c, Drawable d, RectF r) {
        if (d == null) return; d.setBounds((int)r.left,(int)r.top,(int)r.right,(int)r.bottom); d.draw(c);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        gestures.onTouchEvent(e);
        float cardZoneTop = getHeight()*.30f, cardZoneBottom = getHeight()*.82f;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = e.getY()>cardZoneTop && e.getY()<cardZoneBottom;
                if (dragging) { setTag(e.getX()); getParent().requestDisallowInterceptTouchEvent(true); }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) { float last=(float)getTag(); dragX += e.getX()-last; setTag(e.getX()); invalidate(); }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    float threshold = getWidth()*prefs.f("swipe_threshold", .16f);
                    if (Math.abs(dragX)>threshold) animateCard(dragX<0?1:-1); else animateBack();
                }
                dragging=false; return true;
        }
        return true;
    }

    private boolean isInFrontCard(float x,float y) { return y>getHeight()*.30f && y<getHeight()*.82f && Math.abs(x-getWidth()/2f)<getWidth()*.38f; }
    private void animateCard(int direction) {
        float start=dragX, end=-direction*getWidth()*1.05f;
        ValueAnimator a=ValueAnimator.ofFloat(start,end); a.setDuration((long)prefs.i("anim_ms",260));
        a.addUpdateListener(v->{dragX=(float)v.getAnimatedValue(); invalidate();});
        a.addListener(new android.animation.AnimatorListenerAdapter(){@Override public void onAnimationEnd(android.animation.Animator x){front=(front+direction+cardArt.length)%cardArt.length;dragX=0;invalidate();}}); a.start();
    }
    private void animateBack() {
        float start=dragX; ValueAnimator a=ValueAnimator.ofFloat(start,0); a.setDuration(180); a.addUpdateListener(v->{dragX=(float)v.getAnimatedValue();invalidate();}); a.start();
    }
    public void returnToFrontCard(){animateBack();}
    private void launch(String key) {
        try { Intent i=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(android.content.ComponentName.unflattenFromString(key)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); }
        catch(Exception ignored){}
    }
}
