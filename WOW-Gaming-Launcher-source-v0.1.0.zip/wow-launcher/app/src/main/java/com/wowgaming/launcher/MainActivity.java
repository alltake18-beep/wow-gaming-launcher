package com.wowgaming.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

public class MainActivity extends Activity {
    private LauncherView launcherView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(0x00000000);
        getWindow().setNavigationBarColor(0xff090604);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
        launcherView = new LauncherView(this);
        setContentView(launcherView);
    }

    @Override protected void onResume() {
        super.onResume();
        if (launcherView != null) launcherView.reload();
    }

    @Override public void onBackPressed() {
        if (launcherView != null) launcherView.returnToFrontCard();
    }
}
