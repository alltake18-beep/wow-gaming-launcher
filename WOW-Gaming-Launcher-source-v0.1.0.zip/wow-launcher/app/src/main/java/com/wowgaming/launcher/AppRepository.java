package com.wowgaming.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class AppRepository {
    private AppRepository() {}

    public static List<AppEntry> launchable(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(q, PackageManager.MATCH_ALL);
        ArrayList<AppEntry> result = new ArrayList<>();
        for (ResolveInfo r : found) {
            if (r.activityInfo.packageName.equals(context.getPackageName())) continue;
            CharSequence cs = r.loadLabel(pm);
            result.add(new AppEntry(cs == null ? r.activityInfo.name : cs.toString(),
                    new ComponentName(r.activityInfo.packageName, r.activityInfo.name), r.loadIcon(pm)));
        }
        Collections.sort(result, Comparator.comparing(a -> a.label.toLowerCase()));
        return result;
    }

    public static AppEntry findByKey(List<AppEntry> apps, String key) {
        if (key == null) return null;
        for (AppEntry a : apps) if (a.key().equals(key)) return a;
        return null;
    }
}
